library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
entity seg_decoder is
generic
(
  IS_ANODE                  : boolean := false  -- �Ƿ���
);
port
(
  clk                       : in  std_logic;
  din0                      : in  std_logic_vector( 3 downto 0);
  din1                      : in  std_logic_vector( 3 downto 0);
  din2                      : in  std_logic_vector( 3 downto 0);
  din3                      : in  std_logic_vector( 3 downto 0);
  dout                      : out std_logic_vector( 6 downto 0);
  pout                      : out std_logic_vector( 3 downto 0)
);
end entity seg_decoder;

architecture behavior_seg_decoder of seg_decoder is
signal reg_scan             : std_logic_vector(1 downto 0) := (others => '0');
signal reg_data              : std_logic_vector(3 downto 0) := (others => '0');
signal reg_dout             : std_logic_vector(6 downto 0) := (others => '0');
signal reg_port             : std_logic_vector(3 downto 0) := (others => '0');
begin

process(clk)
begin
  if rising_edge(clk) then
    if reg_scan = 3 then
      reg_scan <= (others => '0');
    else
      reg_scan <= reg_scan + 1;
    end if;
  end if;
end process;

process(din0,din1,din2,din3,reg_scan)
begin
  case reg_scan is
    when "00" =>
      reg_data <= din0;
      reg_port(3 downto 1) <= (others => '0');
      reg_port(0) <= '1';
    when "01" =>
      reg_data <= din1;
      reg_port(3 downto 2) <= (others => '0');
      reg_port(1) <= '1';
      reg_port(0) <= '0';
    when "10" =>
      reg_data <= din2;
      reg_port(3) <= '0';
      reg_port(2) <= '1';
      reg_port(1 downto 0) <=(others => '0');
    when "11" =>
        reg_data <= din3;
        reg_port(3) <= '1';
        reg_port(2 downto 0) <=(others => '0');
    when others =>
      reg_data <= (others => '0');
      reg_port <= (others => '0');
  end case;
end process;

process(reg_data)
begin
  case reg_data is
    when "0000" => reg_dout <= "0000001"; -- "0"  0x01
    when "0001" => reg_dout <= "1001111"; -- "1"  0x4F
    when "0010" => reg_dout <= "0010010"; -- "2"  0x22
    when "0011" => reg_dout <= "0000110"; -- "3"  0x06
    when "0100" => reg_dout <= "1001100"; -- "4"  0x4C
    when "0101" => reg_dout <= "0100100"; -- "5"  0x24
    when "0110" => reg_dout <= "0100000"; -- "6"  0x20
    when "0111" => reg_dout <= "0001111"; -- "7"  0x0F
    when "1000" => reg_dout <= "0000000"; -- "8"  0x00
    when "1001" => reg_dout <= "0000100"; -- "9"  0x04
    when "1010" => reg_dout <= "0001000"; -- "A"  0x08
    when "1011" => reg_dout <= "1100000"; -- "B"  0x60
    when "1100" => reg_dout <= "0110001"; -- "C"  0x31
    when "1101" => reg_dout <= "1000010"; -- "D"  0x42
    when "1110" => reg_dout <= "0110000"; -- "E"  0x30
    when "1111" => reg_dout <= "0111000"; -- "F"  0x38
    when others => reg_dout <= "0110000"; -- "E"  0x30
  end case;
end process;

process(reg_dout, reg_port)
begin
  if IS_ANODE then
    dout <= reg_dout;
    pout <= reg_port;
  else
    dout <= not reg_dout;
    pout <= not reg_port;
  end if;
end process;

end architecture behavior_seg_decoder;